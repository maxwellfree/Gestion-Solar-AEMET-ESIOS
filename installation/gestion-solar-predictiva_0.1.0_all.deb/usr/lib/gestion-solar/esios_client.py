#!/usr/bin/env python3
"""
esios_client.py

Cliente básico para acceder a la API de ESIOS.

Autor: Enrique M. Moreno Pérez
"""

import os
from pathlib import Path

import requests
from dotenv import load_dotenv

from config import (
    BASE_URL_ESIOS,
    PRECIO_SPOT,
    PRECIO_COMPRA_PVPC,
    PRECIO_EXCEDENTES,
)


# ==========================================================
# Cargar variables de entorno
# ==========================================================

DIRECTORIO_PROYECTO = Path(__file__).resolve().parent
ARCHIVO_TOKENS = DIRECTORIO_PROYECTO / "mytoken.env"

if not ARCHIVO_TOKENS.exists():
    raise FileNotFoundError(
        f"No se encontró el archivo de claves: {ARCHIVO_TOKENS}"
    )

cargado = load_dotenv(
    dotenv_path=ARCHIVO_TOKENS,
    override=True,
)

if not cargado:
    raise RuntimeError(
        f"No se pudo cargar el archivo: {ARCHIVO_TOKENS}"
    )

API_KEY = os.getenv("ESIOS_API_KEY")

if not API_KEY:
    raise RuntimeError(
        "No se encontró la variable ESIOS_API_KEY en mytoken.env"
    )


# ==========================================================
# Configuración de la API
# ==========================================================

BASE_URL = BASE_URL_ESIOS

HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "x-api-key": API_KEY,
}


# ==========================================================
# Funciones
# ==========================================================

def obtener_indicadores():
    """
    Descarga el catálogo completo de indicadores disponibles.
    """

    response = requests.get(
        f"{BASE_URL}/indicators",
        headers=HEADERS,
        timeout=30,
    )

    response.raise_for_status()

    datos = response.json()

    if "indicators" not in datos:
        raise RuntimeError(
            "La respuesta de ESIOS no contiene el campo 'indicators'."
        )

    return datos["indicators"]


def buscar_indicadores(texto):
    """
    Busca indicadores cuyo nombre contenga el texto indicado.
    """

    texto = texto.lower()

    indicadores = obtener_indicadores()

    encontrados = []

    for indicador in indicadores:

        nombre = indicador["name"]

        if texto in nombre.lower():
            encontrados.append(indicador)

    return encontrados


def mostrar_indicadores(indicadores):
    """
    Muestra una lista de indicadores.
    """

    print(f"\nEncontrados {len(indicadores)} indicadores\n")

    for indicador in indicadores:

        print(f"ID      : {indicador['id']}")
        print(f"Nombre  : {indicador['name']}")

        descripcion = indicador.get("description", "")

        if descripcion:
            descripcion = " ".join(descripcion.split())
            print(f"Descripción : {descripcion[:200]}")

        print("-" * 70)


def comprobar_conexion(indicadores):
    """
    Muestra información básica de la conexión con ESIOS.
    """

    print("==========================================")
    print("Conexión correcta con ESIOS")
    print("==========================================")
    print(f"Número de indicadores: {len(indicadores)}")

    if indicadores:
        primer_nombre = indicadores[0].get(
            "name",
            "Sin nombre",
        )

        print(f"Primer indicador: {primer_nombre}")


# ==========================================================
# Programa principal
# ==========================================================

if __name__ == "__main__":

    try:
        indicadores = obtener_indicadores()

        comprobar_conexion(indicadores)

        print()
        print("Indicadores configurados:")
        print(f"Precio mercado SPOT diario : {PRECIO_SPOT}")
        print(f"Precio de compra PVPC      : {PRECIO_COMPRA_PVPC}")
        print(f"Precio de excedentes       : {PRECIO_EXCEDENTES}")

    except requests.exceptions.Timeout:
        print(
            "Error: la conexión con ESIOS ha excedido "
            "el tiempo máximo de espera."
        )

    except requests.exceptions.HTTPError as error:
        print(f"Error HTTP al consultar ESIOS: {error}")

    except requests.exceptions.RequestException as error:
        print(f"Error de conexión con ESIOS: {error}")

    except (KeyError, ValueError, TypeError) as error:
        print(f"Error al procesar la respuesta de ESIOS: {error}")

# ==========================================================
# Descarga de un indicador
# ==========================================================

def obtener_indicador(
    indicador_id,
    fecha_inicio,
    fecha_fin,
):
    """
    Descarga los valores de un indicador de ESIOS
    para un intervalo de fechas.

    Parameters
    ----------
    indicador_id : int
        Identificador del indicador ESIOS.

    fecha_inicio : str
        Fecha inicial en formato YYYY-MM-DD.

    fecha_fin : str
        Fecha final en formato YYYY-MM-DD.

    Returns
    -------
    dict
        Respuesta completa del indicador devuelta por ESIOS.
    """

    url = f"{BASE_URL}/indicators/{indicador_id}"

    parametros = {
        "start_date": f"{fecha_inicio}T00:00:00",
        "end_date": f"{fecha_fin}T23:59:59",
        "time_trunc": "hour",
        "time_agg": "average",
        "locale": "es",
    }

    response = requests.get(
        url,
        headers=HEADERS,
        params=parametros,
        timeout=30,
    )

    response.raise_for_status()

    datos = response.json()

    if "indicator" not in datos:
        raise RuntimeError(
            f"La respuesta del indicador {indicador_id} "
            "no contiene el campo 'indicator'."
        )

    return datos["indicator"]
