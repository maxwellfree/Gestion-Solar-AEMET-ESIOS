#!/usr/bin/env python3
"""
esios_prices.py

Consulta y presentación de precios eléctricos obtenidos
mediante la API de ESIOS.

Se muestran:

- Precio del mercado SPOT diario para España.
- Precio de compra PVPC para la Península.
- Precio de compensación de excedentes de autoconsumo.

Autor: Enrique M. Moreno Pérez
"""

from datetime import datetime

import requests

from esios_client import obtener_indicador
from config import (
    PRECIO_SPOT,
    PRECIO_COMPRA_PVPC,
    PRECIO_EXCEDENTES,
)


# ==========================================================
# Configuración geográfica
# ==========================================================

GEO_ESPAÑA = 3
GEO_PENINSULA = 8741


# ==========================================================
# Procesamiento de datos
# ==========================================================

def extraer_precios(indicador, geo_id):
    """
    Extrae los valores correspondientes a una zona geográfica.

    Parameters
    ----------
    indicador : dict
        Indicador completo devuelto por la API de ESIOS.

    geo_id : int
        Identificador de la zona geográfica que se desea filtrar.

    Returns
    -------
    list
        Lista de diccionarios con fecha, hora y precios
        en €/MWh y €/kWh.
    """

    resultados = []

    for registro in indicador.get("values", []):

        if registro.get("geo_id") != geo_id:
            continue

        fecha_hora = datetime.strptime(
            registro["datetime"][:19],
            "%Y-%m-%dT%H:%M:%S",
        )

        precio_mwh = float(registro["value"])
        precio_kwh = precio_mwh / 1000.0

        resultados.append(
            {
                "datetime": fecha_hora,
                "hora": fecha_hora.strftime("%H:%M"),
                "precio_mwh": precio_mwh,
                "precio_kwh": precio_kwh,
                "zona": registro.get("geo_name", ""),
            }
        )

    resultados.sort(
        key=lambda registro: registro["datetime"]
    )

    return resultados


def combinar_precios(spot, pvpc, excedentes):
    """
    Combina las tres series de precios por fecha y hora.

    Parameters
    ----------
    spot : list
        Serie del mercado SPOT para España.

    pvpc : list
        Serie del precio de compra PVPC para la Península.

    excedentes : list
        Serie del precio de compensación de excedentes.

    Returns
    -------
    list
        Tabla combinada de precios.
    """

    spot_por_fecha = {
        registro["datetime"]: registro
        for registro in spot
    }

    pvpc_por_fecha = {
        registro["datetime"]: registro
        for registro in pvpc
    }

    excedentes_por_fecha = {
        registro["datetime"]: registro
        for registro in excedentes
    }

    fechas = sorted(
        set(spot_por_fecha)
        & set(pvpc_por_fecha)
        & set(excedentes_por_fecha)
    )

    tabla = []

    for fecha in fechas:

        tabla.append(
            {
                "datetime": fecha,
                "hora": fecha.strftime("%H:%M"),
                "spot": spot_por_fecha[fecha]["precio_kwh"],
                "compra": pvpc_por_fecha[fecha]["precio_kwh"],
                "venta": excedentes_por_fecha[fecha]["precio_kwh"],
            }
        )

    return tabla


# ==========================================================
# Presentación de resultados
# ==========================================================

def mostrar_tabla(tabla):
    """
    Muestra una tabla horaria con los precios eléctricos.
    """

    if not tabla:
        print("No hay datos coincidentes para mostrar.")
        return

    fecha = tabla[0]["datetime"].strftime("%Y-%m-%d")

    print()
    print(f"Precios eléctricos para el día {fecha}")
    print("Valores expresados en €/kWh")
    print()

    print(
        f"{'Hora':<8}"
        f"{'SPOT':>12}"
        f"{'Compra PVPC':>16}"
        f"{'Excedentes':>16}"
        f"{'Diferencia':>16}"
    )

    print("-" * 68)

    for registro in tabla:

        diferencia = (
            registro["compra"]
            - registro["venta"]
        )

        print(
            f"{registro['hora']:<8}"
            f"{registro['spot']:>12.5f}"
            f"{registro['compra']:>16.5f}"
            f"{registro['venta']:>16.5f}"
            f"{diferencia:>16.5f}"
        )


def mostrar_resumen(tabla):
    """
    Muestra los precios mínimos y máximos del día.
    """

    if not tabla:
        return

    minimo_compra = min(
        tabla,
        key=lambda registro: registro["compra"],
    )

    maximo_compra = max(
        tabla,
        key=lambda registro: registro["compra"],
    )

    minimo_venta = min(
        tabla,
        key=lambda registro: registro["venta"],
    )

    maximo_venta = max(
        tabla,
        key=lambda registro: registro["venta"],
    )

    print()
    print("Resumen")
    print("-------")

    print(
        "Compra PVPC mínima : "
        f"{minimo_compra['hora']} — "
        f"{minimo_compra['compra']:.5f} €/kWh"
    )

    print(
        "Compra PVPC máxima : "
        f"{maximo_compra['hora']} — "
        f"{maximo_compra['compra']:.5f} €/kWh"
    )

    print(
        "Excedentes mínimos : "
        f"{minimo_venta['hora']} — "
        f"{minimo_venta['venta']:.5f} €/kWh"
    )

    print(
        "Excedentes máximos : "
        f"{maximo_venta['hora']} — "
        f"{maximo_venta['venta']:.5f} €/kWh"
    )

def mostrar_recomendacion(tabla):
    """
    Muestra una recomendación preliminar basada únicamente
    en los precios horarios.

    Parameters
    ----------
    tabla : list
        Tabla combinada con precios SPOT, compra PVPC
        y compensación de excedentes.
    """

    if not tabla:
        print("No hay datos para generar recomendaciones.")
        return

    horas_consumo = sorted(
        tabla,
        key=lambda registro: registro["compra"],
    )[:3]

    horas_evitar_compra = sorted(
        tabla,
        key=lambda registro: registro["compra"],
        reverse=True,
    )[:3]

    horas_verter = sorted(
        tabla,
        key=lambda registro: registro["venta"],
        reverse=True,
    )[:3]

    print()
    print("Recomendación preliminar")
    print("------------------------")

    print()
    print("Mejores horas para consumir o cargar la batería desde la red:")

    for registro in horas_consumo:
        print(
            f"  {registro['hora']} — "
            f"{registro['compra']:.5f} €/kWh"
        )

    print()
    print("Horas en las que conviene evitar comprar electricidad:")

    for registro in horas_evitar_compra:
        print(
            f"  {registro['hora']} — "
            f"{registro['compra']:.5f} €/kWh"
        )

    print()
    print("Horas con mayor precio de compensación de excedentes:")

    for registro in horas_verter:
        print(
            f"  {registro['hora']} — "
            f"{registro['venta']:.5f} €/kWh"
        )

    mejor_hora_autoconsumo = max(
        tabla,
        key=lambda registro: (
            registro["compra"] - registro["venta"]
        ),
    )

    print()
    print("Prioridad recomendada para la batería:")

    print(
        f"  A las {mejor_hora_autoconsumo['hora']}, "
        "la diferencia entre el precio evitado de compra "
        "y el precio de venta es de "
        f"{mejor_hora_autoconsumo['compra'] - mejor_hora_autoconsumo['venta']:.5f} €/kWh."
    )

    print(
        "  En esa franja resulta más interesante utilizar "
        "la batería para autoconsumo que vender la energía, "
        "siempre que haya demanda en la instalación."
    )


# ==========================================================
# Programa principal
# ==========================================================

if __name__ == "__main__":

    try:
        hoy = datetime.today().strftime("%Y-%m-%d")

        indicador_spot = obtener_indicador(
            PRECIO_SPOT,
            hoy,
            hoy,
        )

        indicador_pvpc = obtener_indicador(
            PRECIO_COMPRA_PVPC,
            hoy,
            hoy,
        )

        indicador_excedentes = obtener_indicador(
            PRECIO_EXCEDENTES,
            hoy,
            hoy,
        )

        precios_spot = extraer_precios(
            indicador_spot,
            GEO_ESPAÑA,
        )

        precios_pvpc = extraer_precios(
            indicador_pvpc,
            GEO_PENINSULA,
        )

        precios_excedentes = extraer_precios(
            indicador_excedentes,
            GEO_ESPAÑA,
        )

        tabla = combinar_precios(
            precios_spot,
            precios_pvpc,
            precios_excedentes,
        )

        mostrar_tabla(tabla)
        mostrar_resumen(tabla)
        mostrar_recomendacion(tabla)

    except requests.exceptions.Timeout:
        print(
            "Error: la conexión con ESIOS ha excedido "
            "el tiempo máximo de espera."
        )

    except requests.exceptions.HTTPError as error:
        print(f"Error HTTP al consultar ESIOS: {error}")

    except requests.exceptions.RequestException as error:
        print(f"Error de conexión con ESIOS: {error}")

    except (
        KeyError,
        ValueError,
        TypeError,
        RuntimeError,
    ) as error:
        print(
            "Error al procesar los datos de ESIOS: "
            f"{error}"
        )
