#!/usr/bin/env python3
"""
gestion_solar.py

Primera integración entre:

- Predicción meteorológica y solar de AEMET.
- Precios eléctricos de ESIOS.
- Recomendación preliminar para una instalación fotovoltaica
  con batería conectada a la red.

Autor: Enrique M. Moreno Pérez
"""

import sys
import argparse
from datetime import datetime

import requests

from aemet_planificador import (
    AEMET_API_KEY,
    obtener_codigo,
    fetch_forecast,
    day_solar_score,
    franja_aproximada,
)

from config import (
    PRECIO_SPOT,
    PRECIO_COMPRA_PVPC,
    PRECIO_EXCEDENTES,
)

from esios_client import obtener_indicador

from esios_prices import (
    GEO_ESPAÑA,
    GEO_PENINSULA,
    extraer_precios,
    combinar_precios,
    mostrar_tabla,
    mostrar_resumen,
)


# ==========================================================
# Predicción meteorológica
# ==========================================================

def obtener_prevision_solar_hoy(nombre_municipio):
    """
    Obtiene la previsión solar correspondiente al día actual.

    Parameters
    ----------
    nombre_municipio : str
        Nombre o código AEMET del municipio.

    Returns
    -------
    dict
        Datos analizados del día actual.
    """

    codigo_municipio = obtener_codigo(
        nombre_municipio
    )

    dias_raw = fetch_forecast(
        codigo_municipio,
        AEMET_API_KEY,
    )

    dias_analizados = [
        day_solar_score(dia)
        for dia in dias_raw
    ]

    hoy = datetime.now().date()

    for dia in dias_analizados:

        if dia["fecha"] == hoy:
            return dia

    raise RuntimeError(
        "AEMET no ha proporcionado una predicción "
        "para el día actual."
    )


# ==========================================================
# Precios eléctricos
# ==========================================================

def obtener_precios_hoy():
    """
    Descarga los precios eléctricos del día actual.

    Returns
    -------
    list
        Tabla horaria combinada con precios SPOT,
        compra PVPC y compensación de excedentes.
    """

    hoy = datetime.now().strftime("%Y-%m-%d")

    indicador_spot = obtener_indicador(
        PRECIO_SPOT,
        hoy,
        hoy,
    )

    indicador_pvpc = obtener_indicador(
        PRECIO_COMPRA_PVPC,
        hoy,
        hoy,
    )

    indicador_excedentes = obtener_indicador(
        PRECIO_EXCEDENTES,
        hoy,
        hoy,
    )

    precios_spot = extraer_precios(
        indicador_spot,
        GEO_ESPAÑA,
    )

    precios_pvpc = extraer_precios(
        indicador_pvpc,
        GEO_PENINSULA,
    )

    precios_excedentes = extraer_precios(
        indicador_excedentes,
        GEO_ESPAÑA,
    )

    tabla = combinar_precios(
        precios_spot,
        precios_pvpc,
        precios_excedentes,
    )

    return tabla


# ==========================================================
# Presentación meteorológica
# ==========================================================

def mostrar_prevision_solar(
    prevision,
    municipio,
):
    """
    Muestra la previsión solar del día actual.
    """

    fecha_txt = prevision["fecha"].strftime(
        "%d/%m/%Y"
    )

    print()
    print("Previsión solar de AEMET")
    print("------------------------")
    print(f"Municipio             : {municipio}")
    print(f"Fecha                 : {fecha_txt}")
    print(
        f"Índice solar          : "
        f"{prevision['score']:.2f}"
    )
    print(
        f"Precipitación prevista: "
        f"{prevision['precip']:.1f} %"
    )
    print(
        f"Temperatura máxima    : "
        f"{prevision['tmax']} °C"
    )
    print(
        f"Franja solar estimada : "
        f"{franja_aproximada(prevision['score'])}"
    )


# ==========================================================
# Recomendación conjunta
# ==========================================================

def mostrar_recomendacion_conjunta(
    tabla,
    prevision,
):
    """
    Genera una recomendación preliminar combinando
    la previsión solar y los precios de la electricidad.
    """

    if not tabla:
        print(
            "No hay precios disponibles para generar "
            "una recomendación."
        )
        return

    score = prevision["score"]

    horas_baratas = sorted(
        tabla,
        key=lambda registro: registro["compra"],
    )[:3]

    horas_caras = sorted(
        tabla,
        key=lambda registro: registro["compra"],
        reverse=True,
    )[:3]

    horas_venta_alta = sorted(
        tabla,
        key=lambda registro: registro["venta"],
        reverse=True,
    )[:3]

    mejor_autoconsumo = max(
        tabla,
        key=lambda registro: (
            registro["compra"]
            - registro["venta"]
        ),
    )

    print()
    print("Recomendación conjunta AEMET–ESIOS")
    print("----------------------------------")

    if score >= 0.75:

        print(
            "Se espera una producción fotovoltaica elevada."
        )

        print(
            "- Utilizar las cargas flexibles durante "
            f"{franja_aproximada(score)}."
        )

        print(
            "- Cargar la batería prioritariamente "
            "con la producción solar."
        )

        print(
            "- No cargar desde la red salvo que el estado "
            "de carga de la batería sea muy bajo."
        )

        print(
            "- Reservar energía para las horas de mayor "
            "precio de compra."
        )

        print(
            "- Verter únicamente la energía que no sea "
            "necesaria para el consumo posterior."
        )

    elif score >= 0.55:

        print(
            "Se espera una producción fotovoltaica intermedia."
        )

        print(
            "- Cargar parcialmente la batería con energía solar."
        )

        print(
            "- Desplazar cargas flexibles a la franja solar."
        )

        print(
            "- Considerar una carga parcial desde red "
            "en las horas más baratas si la batería "
            "queda insuficiente."
        )

        print(
            "- Mantener una reserva para las horas caras."
        )

    else:

        print(
            "Se espera una producción fotovoltaica reducida."
        )

        print(
            "- No confiar en una carga completa mediante "
            "los paneles."
        )

        print(
            "- Considerar cargar la batería desde la red "
            "en las horas de menor precio."
        )

        print(
            "- Reservar la batería para evitar compras "
            "durante las horas más caras."
        )

        print(
            "- Evitar verter energía si puede ser necesaria "
            "para autoconsumo posterior."
        )

    print()
    print("Horas más baratas para consumir o cargar desde red:")

    for registro in horas_baratas:
        print(
            f"  {registro['hora']} — "
            f"{registro['compra']:.5f} €/kWh"
        )

    print()
    print("Horas prioritarias para descargar la batería:")

    for registro in horas_caras:
        print(
            f"  {registro['hora']} — "
            f"{registro['compra']:.5f} €/kWh"
        )

    print()
    print("Horas con mayor compensación de excedentes:")

    for registro in horas_venta_alta:
        print(
            f"  {registro['hora']} — "
            f"{registro['venta']:.5f} €/kWh"
        )

    diferencia = (
        mejor_autoconsumo["compra"]
        - mejor_autoconsumo["venta"]
    )

    print()
    print("Prioridad económica de la batería:")

    print(
        f"  A las {mejor_autoconsumo['hora']}, "
        f"el precio evitado de compra supera al precio "
        f"de venta en {diferencia:.5f} €/kWh."
    )

    if diferencia > 0:

        print(
            "  Si existe consumo en la instalación, "
            "conviene priorizar el autoconsumo con batería "
            "antes que el vertido."
        )

    else:

        print(
            "  El vertido puede ser competitivo en esa franja, "
            "siempre que exista suficiente reserva en la batería."
        )


# ==========================================================
# Programa principal
# ==========================================================

def main():
    """
    Ejecuta la consulta conjunta de AEMET y ESIOS.
    """

    parser = argparse.ArgumentParser(
        description=(
            "Gestión preliminar de una instalación solar "
            "combinando AEMET y ESIOS."
        )
    )

    parser.add_argument(
        "--municipio",
        required=True,
        help=(
            "Nombre o código AEMET del municipio. "
            "Ejemplos: Maracena, Tielmes o 18127."
        ),
    )

    args = parser.parse_args()

    try:
        prevision = obtener_prevision_solar_hoy(
            args.municipio
        )

        tabla = obtener_precios_hoy()

        mostrar_tabla(tabla)
        mostrar_resumen(tabla)

        mostrar_prevision_solar(
            prevision,
            args.municipio,
        )

        mostrar_recomendacion_conjunta(
            tabla,
            prevision,
        )

    except requests.exceptions.Timeout:
        print(
            "Error: alguna consulta ha excedido "
            "el tiempo máximo de espera.",
            file=sys.stderr,
        )

        sys.exit(1)

    except requests.exceptions.HTTPError as error:
        print(
            f"Error HTTP al consultar las APIs: {error}",
            file=sys.stderr,
        )

        sys.exit(1)

    except requests.exceptions.RequestException as error:
        print(
            f"Error de conexión con las APIs: {error}",
            file=sys.stderr,
        )

        sys.exit(1)

    except (
        KeyError,
        ValueError,
        TypeError,
        RuntimeError,
    ) as error:
        print(
            f"Error al procesar los datos: {error}",
            file=sys.stderr,
        )

        sys.exit(1)


if __name__ == "__main__":
    main()
